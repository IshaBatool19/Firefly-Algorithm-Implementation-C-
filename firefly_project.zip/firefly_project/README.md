# Firefly Algorithm (Meta-Heuristic Optimization) — C++

A console program implementing the Firefly Algorithm with a greedy acceptance
step to minimize the objective function f(x) = x^2.

## How it works
- A population of "fireflies" is initialized at random positions in [-10, 10].
- Each firefly's brightness is the value of the objective function at its position
  (lower is "brighter" since we're minimizing).
- Dimmer fireflies move toward brighter ones based on an attraction term that
  decays with distance (controlled by `gamma`) and a random perturbation
  (controlled by `alpha`).
- A greedy check only accepts a move if it actually improves (lowers) brightness;
  otherwise the firefly reverts to its previous position.
- After all generations, the best (lowest-brightness) firefly is reported.

## Files
- `main.cpp`   — full program (menu, algorithm, display)
- `README.md`  — this file

## Build

```bash
g++ -std=c++17 -Wall -o firefly_algorithm main.cpp
```

## Run

```bash
./firefly_algorithm
```

You'll be prompted to either:
1. Run with default parameters (10 fireflies, 5 generations, alpha=0.97, beta=1.0, gamma=0.01), or
2. Customize the number of fireflies, generations, and the alpha/beta/gamma parameters.

The program pauses after each generation ("Press Enter to continue...") so you
can observe how the population converges toward x = 0.
