#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime> //Generating random number
#include <vector>
#include <iomanip> // For formatting output
using namespace std;
// Objective function: f(x) = x^2
double objectiveFunction(double x) {
    return x * x; // Minimize x^2
}
// Generate a random number in a range
double randomInRange(double min, double max) {
    return min + (max - min) * ((double)rand() / RAND_MAX);
}
// Display fireflies' positions and brightness
void displayFireflies(const vector<double>& fireflies, const vector<double>& brightness) {
    cout << setw(10) << "Firefly" << setw(15) << "Position" << setw(15) << "Brightness" << endl;
    cout << "---------------------------------------------" << endl;
    for (size_t i = 0; i < fireflies.size(); i++) {
        cout << setw(10) << i + 1
            << setw(15) << fixed << setprecision(4) << fireflies[i]
            << setw(15) << fixed << setprecision(4) << brightness[i] << endl;
    }
    cout << endl;
}
// Firefly Algorithm with Greedy Approach
void fireflyAlgorithm(int numFireflies, int maxGenerations, double alpha, double beta, double gamma) {
    // Step 1: Initialize fireflies
    vector<double> fireflies(numFireflies);      // Positions of fireflies
    vector<double> brightness(numFireflies);    // Brightness of each firefly
    double minRange = -10.0, maxRange = 10.0;   // Range of positions
    srand(time(0)); // Seed for randomness
    for (int i = 0; i < numFireflies; i++) {
        fireflies[i] = randomInRange(minRange, maxRange);  // Random position
        brightness[i] = objectiveFunction(fireflies[i]);  // Evaluate brightness
    }
    // Main loop: Iterations
    for (int generation = 0; generation < maxGenerations; generation++) {
        cout << "Generation " << generation + 1 << ":" << endl;
        displayFireflies(fireflies, brightness);
        for (int i = 0; i < numFireflies; i++) {
            for (int j = 0; j < numFireflies; j++) {
                if (brightness[i] > brightness[j]) { // Move towards brighter firefly
                    // Step 3: Calculate distance and movement
                    double distance = abs(fireflies[i] - fireflies[j]); // Calculate distance between two fireflies
                    double attraction = beta * exp(-gamma * distance * distance);
                    double randomFactor = alpha * randomInRange(-1.0, 1.0);
                    // Save current position and brightness
                    double previousPosition = fireflies[i];
                    double previousBrightness = brightness[i];
                    // Update position
                    fireflies[i] += attraction * (fireflies[j] - fireflies[i]) + randomFactor;
                    // Calculate new brightness
                    double newBrightness = objectiveFunction(fireflies[i]);
                    // Step 4: Greedy check
                    if (newBrightness < previousBrightness) {
                        brightness[i] = newBrightness; // Accept the new position
                    } else {
                        fireflies[i] = previousPosition; // Revert to the old position
                        brightness[i] = previousBrightness;
                    }
                }
            }
        }
        // Pause to allow the user to observe progress
        cout << "Press Enter to continue to the next generation...";
        cin.clear();
        cin.ignore();
    }
    // Step 5: Find the best solution
    double bestFirefly = fireflies[0];
    double bestBrightness = brightness[0];
    for (int i = 1; i < numFireflies; i++) {
        if (brightness[i] < bestBrightness) { 
            bestFirefly = fireflies[i];
            bestBrightness = brightness[i];
        }
    }
    // Output the best solution
    cout << "\nBest solution found:" << endl;
    cout << "Position: x = " << bestFirefly << endl;
    cout << "Brightness: f(x) = " << bestBrightness << endl;
}
// Menu for the Firefly Algorithm
void menu() {
    int numFireflies, maxGenerations;
    double alpha, beta, gamma;
    cout << ".......................................................................................\n";
    cout << "\n\n\t\t\tMETA HEURISTIC ALGORITHM\n\n";
    cout << "..........................................................................................\n";
    cout << "\n\t\tFIRELY ALGORITHM " << endl;
    cout << "->1. Run with default parameters" << endl;
    cout << "->2. Customize parameters" << endl;
    cout << "Choose an option: ";
    int choice;
    cin >> choice;
    if (choice == 1) {
        numFireflies = 10;
        maxGenerations = 5; // Reduced for demonstration
        alpha = 0.97;
        beta = 1.0;
        gamma = 0.01;
    } else if (choice == 2) {
        cout << "Enter the number of fireflies: ";
        cin >> numFireflies;
        cout << "Enter the maximum number of generations: ";
        cin >> maxGenerations;
        do {
            cout << "Enter the randomness factor (alpha) RANGE:(0 <= alpha <= 1): ";
            cin >> alpha;
        } while (alpha < 0.0 || alpha > 1.0);
        do {
            cout << "Enter the attraction factor (beta) RANGE(0 <= beta <= 1): ";
            cin >> beta;
        } while (beta < 0.0 || beta > 1.0);
        do {
            cout << "Enter the absorption coefficient (gamma) RANGE (gamma > 0): ";
            cin >> gamma;
        } while (gamma <= 0.0);
    } else {
        cout << "Invalid choice! Exiting..." << endl;
        return;
    }
    fireflyAlgorithm(numFireflies, maxGenerations, alpha, beta, gamma);
}
int main() {
    menu();
    return 0;
}
